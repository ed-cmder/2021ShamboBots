import enum
import os
import discord
import pickle
import json
import random

from datetime import datetime, timedelta
from discord import colour
from discord.ext import commands
from discord import Embed
from discord.ext.commands import Cog

from discord.ext.commands.core import has_guild_permissions
###################################################################################################################################


#botConfig = open("botConfig.json", "r").read() #ignore


os.chdir('') #copy the path of the directory that is holding gamble.py, token2.txt bank.json files
#also remove the Gamble.py after pasting the path. Then add another slash otherwise you will get errors: (i.e: \\Bots2021\\Gamble\\ )


#UNCOMMENT this when you saved new token to text(doesn't have to be in a text) otherwise this bot will not work...at all
#Hint: Get new token in Discord Developer Portal after registering the bot!!
#token = open("token2.txt", "r").read()


client = commands.Bot(command_prefix = "!")
#dataFileName = "data.pickle" #ignore for now

#For Poll, Alter it if you have to!
numbers = {"1️⃣", "2️⃣", "3️⃣", "4️⃣", "5️⃣"}

#Class Data for Bank & Wallet
class Data():
    def __init__(self, wallet, bank):
        self.wallet = wallet
        self.bank = bank

@client.event
async def on_ready():
    print('Bot is ready')
    print("Logged in as {0.user}".format(client))
###################################################################################################################################
"""
@client.command(pass_context=True)
async def clear(ctx, amount=100):
    channel = ctx.message.channel
    messages = []
    async for message in client.logs_from(channel, limit=int(amount)):
        messages.append(message)
    await client.delete_messages(messages)
"""
######################################### BANK & WALLET ##############################################################
"""
 7/6/21 - Edited by A$AP ZEN [✔️]

 In this section, the bot can be commanded to display the bank & wallet amount for a user in a Discord Server/Channel.
 Fundamentally, rather simple. User invokes balance command (!balance) users can also tag other members in channel
 Data for bank & wallet is written to a JSON File. This is created for now, thoughts of implementing daily rewards in under consideration.
 But this is good for now. 

 Within the bank.json file. Once a user invokes the balance command, data pertaining to the user will be stored in the bank.json file.
 In there admin can change the amount..if he/she chooses.

  * Next major step is implement database: []  - "Eddie"
  * Minor change: Send balance as private message? Doesn't have to but a suggestion.

"""

async def open_account(user):
    users = await get_bank_data()

    if str(user.id) in users:
        return False
    else:
        users[str(user.id)] = {}
        users[str(user.id)]["wallet"] = 0 # this can be altered.
        users[str(user.id)]["bank"] = 300 # this can be changed but be vigilant on the bank amount....
    #reading the data from the json file
    with open("bank.json", "w") as f:
        json.dump(users, f, indent=4)
    
    return True


async def get_bank_data():
    with open("bank.json", "r") as f:
        users = json.load(f)
    
    return users #outputting users


async def update_bank(user, change=0, mode="wallet"):
    users = await get_bank_data()

    users[str(user.id)][mode] += change
    #writing data to the json file
    with open("bank.json", "w") as f:
        json.dump(users, f, indent=4)

    bal = [users[str(user.id)]["wallet"]],[users[str(user.id)]["bank"]]
    return bal #returning the balance

#This is the command that users can invoke
@client.command()
async def balance(ctx, member: discord.Member = None):
    if not member:
        member = ctx.author
    await open_account(member)

    users = await get_bank_data()
    user = member

    wallet_amount = users[str(user.id)]["wallet"]
    bank_amount = users[str(user.id)]["bank"]

    balEmbed = discord.Embed(title = f"{member.name}'s Balance", colour = discord.Color.blue())
    balEmbed.add_field(name="Wallet", value= wallet_amount)
    balEmbed.add_field(name="Bank", value= bank_amount)

    await ctx.send(embed=balEmbed)

#loaning from the bot
@client.command()
async def loan(ctx):

    await open_account(ctx.author)
    users = await get_bank_data()
    user = ctx.author
    earnings = random.randrange(400) #can change amount

    await ctx.send(f"Bot has loaned you ${earnings}!")

    users[str(user.id)]["wallet"] += earnings

    with open("bank.json", "w") as f:
        json.dump(users, f, indent=4)

###################################################################################################################################
#daily reward <-- This I can see being useful and generating $
"""
Work in progress - "Eddie"
Can alter this if you wish
"""
@client.event
async def dailyrewards(ctx, bot, message, member):
    timeout = 86400000
    reward = 250
    rewardEmbed = discord.Embed(title = f"{member.name}")

###################################################################################################################################
#Command for betting
"""
HERE IS WHERE THE MAIN PURPOSE OF THIS BOT!
"""
@client.command()
async def bet(ctx):
    embed = discord.Embed()


################################# TEST POLL ALPHA ##################################################################################################
"""
Embeded Message: An interface for displaying what the bet will be..
(i.e. A PPV UFC Event, who is fighting, & users setting their predictions..)
Command: !play
This section only covers the UFC 264 McGregor vs Poirier..again..a test
"""
#TESTING!! - IT WORKS...kind of!!
@client.command()
async def ufc(ctx, *, message):
    emb = discord.Embed(
        title= " UFC 264 ",
        description =f"{message}",colour = discord.Colour.blue())

    msg = await ctx.channel.send(embed=emb)
    
    await msg.add_reaction('☘')
    await msg.add_reaction('⚜')

################################### TEST POLL BETA ################################################################################################
"""
Create a poll 
Not complete however I do believe we need to tie in the gamble command with this! - "Eddie"

@client.command()
async def create_poll(self, ctx, hours: int, question: str, *options):
    if len(options) > 5:
        await ctx.send("You can only supply a maximum of 5 options.")

    else:
        embed = Embed(title = "Poll", description=question, colour=discord.Colour.blue(), timestamp=datetime.utcnow())

        fields = [("Options", "\n".join([f"{numbers[idx]} {option}" for idx, option in enumerate(options)]), False), ("Instructions", "React to cast a vote!", False)]

        for name, value, inline in fields:
            embed.add_field(name=name, value=value, inline=inline)

        message = await ctx.send(embed=embed)

        for emoji in numbers[: len(options)]:
            await message.add_reaction(emoji)
        
        self.polls.append((message.channel.id, message.id))

        self.bot.scheduler.add_job(self.complete_poll, "date", run_date=datetime.now() + timedelta(seconds=hours), args=[message.channel.id, message.id])

async def complete_poll(self, channel_id, message_id):
    message = await self.bot.get_channel(channel_id).fetch_message(message_id)

    most_voted = max(message.reactions, key=lambda r: r.count)

    #await message.channel.send(f"Results are in and option{most_voted.emoji} *insert message here* {most_voted.count-1:,}")
    #self.polls.remove((message.channel.id, message.id))
"""
##################################### TEST POLL SAMPLE ##############################################################################################

"""
#Embed Message for displaying what the bet/vote system could be..
@client.command()
async def play(ctx, message , message2):
    emb = discord.Embed(
        title = 'Gamble Bot',
        description = f"{message}",
        colour = discord.Colour.blue()
    )
    msg = await ctx.channel.send(embed=emb)
    emb.add_field(name='Field Value', value='Field Value', inline=False) # Example: UFC 264
    emb.add_field(name='Field Value', value='Field Value', inline=True)  # Example: Name = 'Conor McGregor' Value = ☘
    emb.add_field(name='Field Value', value='Field Value', inline=True)  # Example: Name = 'Dustin Poirier' Value = ⚜
    await msg.add_reaction('☘')
    await msg.add_reaction('⚜')

    await ctx.send(embed=emb)
""" 

###################################################################################################################################



client.run(token) #uncomment token variable !!!